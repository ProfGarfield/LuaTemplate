local four = {}

function four.doThis(gameYear)
    civ.ui.text("This is context Nine, and the year is "..tostring(gameYear)..".")
end

return four
