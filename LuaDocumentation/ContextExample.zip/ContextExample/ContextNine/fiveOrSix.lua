local contextEvents = {}

function contextEvents.five(leaderName)
    civ.ui.text("Hello "..leaderName.."!  This is context Nine.")
end

function contextEvents.six()
    civ.ui.text("This is context Nine, and six was pressed.")
end

return contextEvents
