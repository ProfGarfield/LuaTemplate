-- add the line
--[[
local contextExample = require("contextExample")
--]]
-- to events.lua or some other file required by events.lua
-- in order to make this context example run.

local counter = require("counter")
local context = require("context")
local discreteEvents = require("discreteEventsRegistrar")
local keyboard = require("keyboard")

counter.define("contextChooser",7) -- this counter determines the 'context' that
-- is currently active.  Many 'context' applications wouldn't change due to
-- events in the game, but would be set at the beginning of the game
-- or determined by some fundamental characteristic, such as which
-- tribe is being played, or whether the game is a single
-- player version or multiplayer version

-- Here, there are 3 possible contexts, 7, 8, and 9, which are toggled by key presses.  
-- Contexts 8 and 9 have their data stored in the folders
-- ContextEight and ContextNine respectively.
--  Context 7 has no data, so return nil instead of a folder name

local function contextChooser()
    if counter.value("contextChooser") == 7 then
        return nil
    elseif counter.value("contextChooser") == 8 then
        return "ContextEight"
    elseif counter.value("contextChooser") == 9 then
        return "ContextNine"
    else
        return nil
    end
end

-- the context selection function must be registered
context.registerSelectContext(contextChooser)

-- We'll register some key press events
-- to change the context
function discreteEvents.onKeyPress(keyID)
    if keyID == keyboard.seven then
        civ.ui.text("Context changed to Seven")
        counter.setValue("contextChooser",7)
    end
end
function discreteEvents.onKeyPress(keyID)
    if keyID == keyboard.eight then
        civ.ui.text("Context changed to Eight")
        counter.setValue("contextChooser",8)
    end
end
function discreteEvents.onKeyPress(keyID)
    if keyID == keyboard.nine then
        civ.ui.text("Context changed to Nine")
        counter.setValue("contextChooser",9)
    end
end

-- now, let's write some context dependent events

function discreteEvents.onKeyPress(keyID)
    if keyID == keyboard.four then
        context.four.doThis(civ.getGameYear())
    elseif keyID == keyboard.five then
        context.fiveOrSix.five(civ.getCurrentTribe().leader.name)
    elseif keyID == keyboard.six then
        context.fiveOrSix.six()
    end
end
