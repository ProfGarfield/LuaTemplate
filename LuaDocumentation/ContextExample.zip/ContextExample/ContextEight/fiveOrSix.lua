local contextEvents = {}

function contextEvents.five(leaderName)
    civ.ui.text("Hello "..leaderName.."!  This is context eight.")
end

function contextEvents.six()
    civ.ui.text("This is context Eight, and six was pressed.")
end

return contextEvents
